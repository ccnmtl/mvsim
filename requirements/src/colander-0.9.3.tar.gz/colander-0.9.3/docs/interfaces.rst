Interfaces
----------

.. automodule:: colander.interfaces

  .. autofunction:: Preparer

  .. autofunction:: Validator

  .. autoclass:: Type
     :members:


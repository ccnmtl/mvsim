.. _glossary:

Glossary
========

.. glossary::
   :sorted:

   WebOb
     `WebOb <http://pythonpaste.org/webob/>`_ is a WSGI request/response
     library created by Ian Bicking.

Peppercorn
==========

A library for converting a token stream into a data structure
comprised of sequences, mappings, and scalars, developed primarily for
converting HTTP form post data into a richer data structure.

Please see `http://docs.repoze.org/peppercorn
<http://docs.repoze.org/peppercorn>`_ for the documentation.
